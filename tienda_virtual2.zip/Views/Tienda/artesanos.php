<?php
headerTienda($data);
$arrArtesanos = $data['artesanos'];
$arrProdArtesanos = $data['prod_artesanos'];
?>
<br><br><br>
<hr>
<!-- Product -->
<div class="bg0 m-t-23 p-b-140">
	<div class="container">
		<div class="flex-w flex-sb-m p-b-52">
			<div class="flex-w flex-l-m filter-tope-group m-tb-10">
				<?php
				if (count($data['artesanos']) > 0) {
					foreach ($data['artesanos'] as $artesanos) {
				?>
						<section class="bg0 p-t-75 p-b-120">
							<div class="container">
								<div class="row p-b-148">
									<div class="col-md-7 col-lg-8">
										<div class="p-t-7 p-r-85 p-r-15-lg p-r-0-md">
											<h3 class="mtext-111 cl2 p-b-16">
												<?= $artesanos['nombres'] ?> <?= $artesanos['apellidos'] ?>
											</h3>

											<p class="stext-113 cl6 p-b-26">
												<!-- <?= $artesanos['nombres'] ?> -->
												Breve descripción de cada artesano individualmente, como carta de presentación al publico.
											</p>
										</div>
									</div>

									<div class="col-11 col-md-5 col-lg-4 m-lr-auto">
										<div class="how-bor1 ">
											<div class="hov-img0">

												<img src="<?= media() . '/images/uploads/' . $artesanos['portada'] ?>">
											</div>
											<a href="https://api.whatsapp.com/send?phone=<?= "57" . $artesanos['telefono'] ?>" target="_blank" class="fs-14 cl3 hov-cl1 trans-04 lh-10 p-lr-5 p-tb-2 m-r-8 tooltip100" data-tooltip="WhatsApp">
												Contactar por whatsapp al artesano <i class="fab fa-whatsapp" aria-hidden="true"></i>
											</a>
										</div>
									</div>
								</div>
							</div>
							<div class="bg6 flex-c-m flex-w size-302 m-t-73 p-tb-15">
								<h3>Productos de este artesano</h3>
							</div>
						</section>
				<?php
					}
				}
				?>
			</div>
			<!-- Related Products -->
			<section class="sec-relate-product bg0 p-t-45 p-b-105">
				<div class="container">
					<!-- Slide2 -->
					<div class="wrap-slick2">
						<div class="slick2">
							<?php
							for ($j = 0; $j < count($arrProdArtesanos); $j++) {
								$ruta = $arrProdArtesanos[$j]['ruta'];
							?>
								<h1><?$ruta["codigo"]?></h1>
							<?php } ?>

						</div>
					</div>
				</div>
			</section>
		</div>
	</div>
	<?php
	footerTienda($data);
	?>