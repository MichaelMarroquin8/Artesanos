<?php
headerTienda($data);
$arrArtesanos = $data['informacionArtesano'];
?>
<br><br><br>
<hr>
<!-- Product -->
<div class="bg0 m-t-23 p-b-140">

	<div class="container">
		<div class="flex-w flex-sb-m p-b-52">
			<div class="flex-w flex-l-m filter-tope-group m-tb-10">aa</div>

		</div>
	</div>
</div>
<?php
footerTienda($data);
?>